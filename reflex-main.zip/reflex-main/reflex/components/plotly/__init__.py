"""Plotly components."""

from .plotly import Plotly

plotly = Plotly.create
