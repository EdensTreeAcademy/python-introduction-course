"""Display the page body."""

from reflex.components.component import Component


class Body(Component):
    """A body component."""

    tag = "body"
