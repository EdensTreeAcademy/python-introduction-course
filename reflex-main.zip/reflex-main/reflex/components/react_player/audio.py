"""A audio component."""
from reflex.components.react_player.react_player import ReactPlayer


class Audio(ReactPlayer):
    """Audio component share with Video component."""

    pass
