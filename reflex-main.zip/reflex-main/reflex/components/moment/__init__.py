"""Moment.js component."""

from .moment import Moment

moment = Moment.create
