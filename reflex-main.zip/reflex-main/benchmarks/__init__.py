"""Reflex benchmarks."""

WINDOWS_SKIP_REASON = "Takes too much time as a result of npm"
