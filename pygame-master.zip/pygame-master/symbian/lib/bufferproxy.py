from pygame_bufferproxy import * 
