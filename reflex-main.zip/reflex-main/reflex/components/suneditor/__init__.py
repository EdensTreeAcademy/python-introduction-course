"""Editor component."""

from .editor import Editor, EditorButtonList, EditorOptions

editor = Editor.create
