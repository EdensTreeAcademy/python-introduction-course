"""Shim for reflex.components.chakra.media.icon."""
from reflex.components.chakra.media.icon import *
