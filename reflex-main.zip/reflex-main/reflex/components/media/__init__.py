"""Temporary shim for Chakra icon class."""
