"""Component tests."""
